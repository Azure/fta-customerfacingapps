﻿namespace Contoso.Financial.Core.Api.Models
{
    public class BalanceModel
    {
        public double AvailableBalance { get; set; }
    }
}