﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using Contoso.Financial.Core.Api.Models;
using Dapper;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace Contoso.Financial.Core.Api.Controllers
{
    [Route("api/[controller]")]
    public class TransactionsController : Controller
    {
        [SwaggerOperation("Get")]
        [HttpGet]
        public IEnumerable<TransactionModel> Get()
        {
            var connString = Environment.GetEnvironmentVariable("TransactionDb");

            using (var con = new SqlConnection(connString))
            {
                var data = con.Query<TransactionModel>(
                    "SELECT TOP 25 * FROM [Transaction] ORDER BY [DateTime] DESC");

                return from d in data
                       orderby d.DateTime
                       select d;
            }
        }
    }
}