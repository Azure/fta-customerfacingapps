﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using Contoso.Financial.Core.Api.Models;
using Microsoft.AspNetCore.Mvc;
using Swashbuckle.AspNetCore.SwaggerGen;

namespace Contoso.Financial.Core.Api.Controllers
{
    [Route("api/[controller]")]
    public class BalanceController : Controller
    {
        [SwaggerOperation("Get")]
        [HttpGet]
        public BalanceModel Get()
        {
            var connString = Environment.GetEnvironmentVariable("TransactionDb");

            using (var con = new SqlConnection(connString))
            {
                using (var cmd = con.CreateCommand())
                {
                    cmd.CommandType = System.Data.CommandType.StoredProcedure;
                    cmd.CommandText = "GetBalance";

                    con.Open();
                    double? availableBalance = cmd.ExecuteScalar() as double?;
                    con.Close();

                    return new BalanceModel
                    {
                        AvailableBalance = availableBalance.Value
                    };

                }
            }
        }
    }
}